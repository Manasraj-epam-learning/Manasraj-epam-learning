"""A small checklist-based evaluator for prompt/response pairs.

Each test case has a prompt, a model response and simple criteria written by a human.
The evaluator scores four dimensions between 0 and 1:

  relevance            share of expected topic words that appear in the response
  accuracy             1.0 unless the response contains a phrase known to be wrong
  completeness         share of required points the response covers
  instruction adherence  stays within the word limit (deeper checks live in Instruction-Evals)

This is KEYWORD matching. It does not understand meaning, so it can be fooled
(see the two "limitation" cases in examples/test_cases.json).
"""

import json
import re
import sys
from pathlib import Path

TEST_CASES_PATH = Path(__file__).parent.parent / "examples" / "test_cases.json"

# A criterion passes when its score reaches this minimum.
PASS_THRESHOLDS = {"relevance": 0.5, "accuracy": 1.0, "completeness": 0.75, "adherence": 1.0}
WEIGHTS = {"relevance": 0.25, "accuracy": 0.30, "completeness": 0.30, "adherence": 0.15}


def contains_word(text, phrase):
    """True if the phrase appears as whole words (so 'mutable' does not match 'immutable')."""
    return re.search(rf"\b{re.escape(phrase.lower())}\b", text.lower()) is not None


def score_relevance(response, relevance_terms):
    if not relevance_terms:
        return 1.0
    return sum(contains_word(response, term) for term in relevance_terms) / len(relevance_terms)


def score_accuracy(response, forbidden_claims):
    return 0.0 if any(contains_word(response, claim) for claim in forbidden_claims) else 1.0


def score_completeness(response, required_topics):
    """Each topic is a list of acceptable synonyms; one match covers the topic."""
    if not required_topics:
        return 1.0
    covered = sum(any(contains_word(response, synonym) for synonym in topic) for topic in required_topics)
    return covered / len(required_topics)


def score_adherence(response, max_words):
    return 1.0 if max_words is None or len(response.split()) <= max_words else 0.0


def evaluate(response, criteria):
    scores = {
        "relevance": score_relevance(response, criteria.get("relevance_terms", [])),
        "accuracy": score_accuracy(response, criteria.get("forbidden_claims", [])),
        "completeness": score_completeness(response, criteria.get("required_topics", [])),
        "adherence": score_adherence(response, criteria.get("max_words")),
    }
    failed = [name for name, score in scores.items() if score < PASS_THRESHOLDS[name]]
    weighted_score = sum(scores[name] * WEIGHTS[name] for name in scores)
    return {"scores": scores, "weighted_score": weighted_score,
            "verdict": "FAIL" if failed else "PASS", "failed_criteria": failed}


def load_test_cases(path=TEST_CASES_PATH):
    with open(path, encoding="utf-8") as file:
        return json.load(file)


def main():
    cases = load_test_cases()
    agreements = 0
    for case in cases:
        result = evaluate(case["response"], case["criteria"])
        agrees = result["verdict"] == case["human_verdict"]
        agreements += agrees
        scores = "  ".join(f"{name}={score:.2f}" for name, score in result["scores"].items())
        print(f"[{case['id']}] {case['description']}")
        print(f"  {scores}  weighted={result['weighted_score']:.2f}")
        failed = ", ".join(result["failed_criteria"]) or "none"
        print(f"  evaluator: {result['verdict']} (failed: {failed}) | human: {case['human_verdict']} | "
              f"{'agree' if agrees else 'DISAGREE'}\n")
    print(f"Evaluator agreed with the human verdict on {agreements} of {len(cases)} cases.")
    print("Disagreements show the limits of keyword matching.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
