# Prompt Evaluation: Short Notes

Status: in progress. These are introductory notes.

## What is prompt evaluation?

A prompt is the instruction given to a generative AI model. **Prompt evaluation** is the process of checking how well a prompt works: does it consistently lead the model to useful, correct and appropriately formatted responses?

Because language models can give different answers to similar inputs, a prompt that worked once may not be reliable. Evaluation replaces "it looked good to me" with a repeatable check.

## Why it matters

- **Quality**: finds prompts that produce wrong, vague or off-topic answers.
- **Comparison**: lets you compare prompt version A with version B using the same test cases.
- **Regression checking**: confirms that changing a prompt did not break cases that used to work.
- **Trust**: outputs used in real products need evidence of reliability, not a single good example.

## Basic evaluation criteria

| Criterion | Question it answers | Example failure |
|-----------|--------------------|-----------------|
| Relevance | Does the response address what was asked? | Answers about cooking when asked about Python |
| Accuracy | Is the information correct? | States that Python lists are immutable |
| Completeness | Does it cover every requested point? | Mentions "ordered" but forgets "mutable" |
| Instruction adherence | Does it follow the stated constraints (length, format, tone)? | Writes 80 words when asked for 60 or fewer |

Other criteria seen in practice: clarity, tone, safety, consistency across repeated runs.

## A simple evaluation process

1. Write the prompt and decide what a good answer must contain.
2. Create several test cases, including normal, tricky and clearly bad responses.
3. Score each response against the criteria (by a human, by a program, or both).
4. Look at the failures, improve the prompt, and run the same test cases again.

## Evaluation methods

- **Human review**: most reliable for meaning and quality, but slow and subjective.
- **Rule or keyword checks** (used in this repository): fast, repeatable and transparent, but shallow.
- **Reference comparison**: compare to a known correct answer.
- **LLM-as-a-judge**: another model scores the response. Scalable, but the judge can also be wrong or biased, so it needs spot-checking by humans.

## Limitations of simple keyword-based evaluation

The implementation in `code/prompt_checklist.py` is deliberately simple, and its limits are shown by real test cases:

1. **It cannot understand meaning.** "A list is not ordered and not mutable" contains both keywords, so it passes completeness although it is wrong (`limitation_false_pass`).
2. **It misses paraphrases.** "Keeps its items in a fixed sequence" is correct but contains no listed keyword, so it fails (`limitation_false_fail`). Adding more synonyms helps only partly.
3. **It only catches mistakes someone predicted.** The accuracy check looks for a list of known-wrong phrases. A new kind of error goes undetected.
4. **It does not judge quality.** Clarity, tone, structure and usefulness are not measured.
5. **Scores depend on the criteria written by a human.** Weak criteria give misleading results.

Keyword checks are therefore useful as a quick first filter and for repeatable regression tests, but not as proof that a response is good.

## Prompt evaluation vs. instruction evaluation

Briefly: prompt evaluation asks "is this prompt and its response good overall?", while instruction evaluation asks "did the response do exactly what the instructions said?". See `Instruction-Evals/notes/instruction_evals.md` for the comparison.

## What I want to learn next

Writing larger test sets, measuring consistency over repeated runs, and trying LLM-as-a-judge with human spot checks.
