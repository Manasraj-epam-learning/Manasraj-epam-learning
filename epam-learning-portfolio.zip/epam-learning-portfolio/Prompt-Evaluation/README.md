# Prompt Evaluation

**Status: IN PROGRESS**

## Overview

Prompt evaluation is the practice of checking whether a prompt leads a language model to responses that are relevant, accurate, complete and compliant with instructions. This folder contains introductory notes and a small Python checklist evaluator that scores prompt/response pairs.

## Concepts covered so far

- What prompt evaluation is and why it matters
- Four basic criteria: relevance, accuracy, completeness, instruction adherence
- A simple evaluation process and common methods (human review, rules, LLM-as-a-judge)
- Limitations of keyword-based evaluation

## Folder structure

```
Prompt-Evaluation/
├── README.md
├── notes/
│   └── prompt_evaluation.md
├── code/
│   └── prompt_checklist.py     # checklist evaluator (standard library only)
└── examples/
    ├── test_cases.json         # 7 test cases: good, bad and limitation cases
    └── sample_output.txt       # output of the evaluator
```

## How it works

Each test case in `examples/test_cases.json` has a prompt, a response, simple criteria written by a human (expected keywords, required points, known-wrong phrases, word limit) and a `human_verdict`. The evaluator scores four criteria between 0 and 1. A response passes only if **every** criterion reaches its threshold. The program then compares its verdict with the human verdict.

The "limitation" test cases are intentional: they show where the evaluator is wrong.

## How to run

Requires Python 3.8 or later. Run from inside the `Prompt-Evaluation` folder:

```bash
python code/prompt_checklist.py
```

## Expected output (shortened)

```text
[good_response] Correct, complete, on-topic and short enough
  relevance=1.00  accuracy=1.00  completeness=1.00  adherence=1.00  weighted=1.00
  evaluator: PASS (failed: none) | human: PASS | agree
...
[limitation_false_pass] LIMITATION: keywords are present but the meaning is wrong (negation)
  relevance=1.00  accuracy=1.00  completeness=1.00  adherence=1.00  weighted=1.00
  evaluator: PASS (failed: none) | human: FAIL | DISAGREE

[limitation_false_fail] LIMITATION: correct answer in different words is not recognised
  relevance=1.00  accuracy=1.00  completeness=0.00  adherence=1.00  weighted=0.70
  evaluator: FAIL (failed: completeness) | human: PASS | DISAGREE

Evaluator agreed with the human verdict on 5 of 7 cases.
Disagreements show the limits of keyword matching.
```

The full output is in `examples/sample_output.txt`.

## Key learning outcomes so far

- I can define evaluation criteria and turn them into automated checks.
- I understand that a repeatable test set is more reliable than judging one answer by eye.
- I can explain why keyword matching is fast and transparent but cannot understand meaning (negation, paraphrase).
- I know that automated checks should be backed by human review.
