# AI Agents

**Status: IN PROGRESS**

## Overview

An AI agent observes its environment, decides what to do to reach a goal, and acts, usually by calling tools. This folder has introductory notes and a small agent that shows the Observe, Decide, Act loop.

**Important:** the agent in this folder is **rule-based**. It contains no machine-learning model and calls no external API. It demonstrates the *structure* of an agent, not the intelligence of an LLM-based one.

## Concepts covered so far

- Definition of an agent and how it differs from a simple function
- Components: goal, observation, decision logic, action, tools, memory
- The Observe, Decide, Act loop
- Rule-based vs. LLM-based vs. learning-based decision making
- Basic design points: stopping condition, handling unknown input, safe tools

## Folder structure

```
AI-Agents/
├── README.md
├── notes/
│   └── ai_agents.md
├── code/
│   └── simple_agent.py         # rule-based agent with 4 tools
└── examples/
    ├── demo_inputs.txt         # inputs used by --demo
    └── sample_output.txt       # output of the demo run
```

## The agent

| Part | Implementation |
|------|----------------|
| Goal | Help the user with simple tasks |
| Observation | The text typed by the user, cleaned by `observe()` |
| Decision | `decide()` matches the text against patterns and returns a `Decision` (tool, arguments, reason) |
| Action | `act()` runs the chosen tool |
| Tools | Calculator, unit converter, word counter, to-do list |
| Memory | The task list and a history of requests |
| Stop condition | The user types `bye`, `quit` or `exit` |

## How to run

Requires Python 3.8 or later. Run from inside the `AI-Agents` folder:

```bash
python code/simple_agent.py --demo    # runs the inputs in examples/demo_inputs.txt
python code/simple_agent.py           # interactive mode; type 'help' for options
```

## Expected output (shortened)

```text
Observe: 'add task finish python practice'
Decide : tool=add_task (matched 'add task')
Act    : Added task #1: finish python practice

Observe: 'add task revise prompt evaluation notes'
Decide : tool=add_task (matched 'add task')
Act    : Added task #2: revise prompt evaluation notes

Observe: 'show tasks'
Decide : tool=show_tasks (matched 'show tasks')
Act    : Tasks: 1. finish python practice; 2. revise prompt evaluation notes
...
Observe: 'convert 5 km to fahrenheit'
Decide : tool=converter (matched conversion request)
Act    : Error: I cannot convert km to fahrenheit.

Observe: 'count words in agents observe decide and act'
Decide : tool=word_count (matched word-count request)
Act    : The text has 5 words.

Observe: 'tell me a joke'
Decide : tool=none (no rule matched)
Act    : I did not understand that. Type 'help' to see what I can do.
...
Session summary: 13 requests handled, 2 tasks stored.
```

The demo covers valid requests, an error case (division by zero), an unsupported conversion, an unknown request and empty input. The full output is in `examples/sample_output.txt`.

## Limitations

- It understands only the sentence patterns written in `decide()`. "What's 5 plus 3?" is not understood.
- The to-do list is lost when the program ends (no file storage).
- It cannot plan multiple steps; each request is handled independently.

## Key learning outcomes so far

- I can explain the parts of an agent and the Observe, Decide, Act loop.
- I can structure code so that tools, decision logic and memory are separate.
- I understand that an LLM-based agent would replace the rule matching in `decide()`.
- I handle unknown input and errors instead of guessing.
