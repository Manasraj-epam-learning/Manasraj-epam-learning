# AI Agents: Short Notes

Status: in progress. These are introductory notes.

## What is an AI agent?

An **agent** is a system that perceives its environment, decides what to do to reach a goal, and takes actions that change that environment. The key difference from a plain function or chatbot is the **loop**: the agent keeps observing, deciding and acting, and its next decision can depend on what happened before.

## Basic components

| Component | Meaning | Example in my project |
|-----------|---------|-----------------------|
| Goal | What the agent is trying to achieve | Help the user complete a request correctly |
| Observation | The input the agent perceives | The text the user typed |
| Decision logic | How the agent chooses an action | Matching the request to a tool |
| Action | Something the agent does | Calling a tool, or asking for clarification |
| Tools | Functions the agent can call | Calculator, unit converter, word counter, to-do list |
| Memory | What the agent remembers | The to-do list and a history of actions |

## The Observe, Decide, Act loop

```
        +----------+      +----------+      +---------+
 input  | OBSERVE  | ---> |  DECIDE  | ---> |   ACT   | ---> result
------> | read the |      | choose a |      | run the |
        | request  |      | tool     |      | tool    |
        +----------+      +----------+      +---------+
              ^                                  |
              +---------- update memory ---------+
```

1. **Observe**: receive and clean up the input.
2. **Decide**: pick an action (or choose to ask for clarification, or to stop).
3. **Act**: execute the action and return the result.
4. Repeat until the goal is met or the user ends the session.

## How decisions can be made

- **Rule-based** (used in this repository): explicit if/else and pattern rules. Predictable and easy to explain, but only handles inputs the rules anticipate.
- **LLM-based**: a language model reads the request and the list of available tools and chooses which to call. Flexible with free-form input, but less predictable and it needs testing.
- **Learning-based**: for example reinforcement learning, where the agent learns a policy from rewards.

Modern "LLM agents" usually combine a language model for decisions with tools such as search, code execution or APIs.

## Good design points

- Give tools clear, narrow jobs and validate their inputs.
- Handle the "I don't understand" case instead of guessing.
- Keep a clear stopping condition so the loop cannot run forever.
- Keep humans in control of risky actions (deleting data, spending money, sending messages).
- Log decisions so behaviour can be reviewed.

## My implementation

`code/simple_agent.py` is a small **rule-based** agent. It uses no AI model and no external API. It is not intelligent in the way an LLM agent is. It demonstrates the structure (goal, observation, decision, action, tools, memory) that an LLM-based agent would also have; the difference is that an LLM would replace the rule-matching in `decide()`.

## What I want to learn next

How an LLM chooses tools (function calling), multi-step planning, and how agents are tested and evaluated, which links to the evaluation topics in this repository.
