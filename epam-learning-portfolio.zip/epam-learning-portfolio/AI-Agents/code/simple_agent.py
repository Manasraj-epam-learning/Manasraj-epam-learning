"""A small rule-based agent that follows the Observe -> Decide -> Act loop.

Goal   : help the user with simple tasks using a fixed set of tools.
Tools  : calculator, unit converter, word counter, to-do list.
Memory : the to-do list and a history of actions.

IMPORTANT: this agent contains no machine-learning model. Its decide() step uses
pattern matching, so it only understands the sentence shapes written below. An
LLM-based agent would replace decide() with a model call; the loop stays the same.

Usage:
    python code/simple_agent.py            # interactive mode
    python code/simple_agent.py --demo     # run the inputs in examples/demo_inputs.txt
"""

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

DEMO_FILE = Path(__file__).parent.parent / "examples" / "demo_inputs.txt"
NUMBER = r"-?\d+(?:\.\d+)?"


# ---------------------------------------------------------------- tools
def calculator_tool(left, operator, right):
    if operator == "+":
        answer = left + right
    elif operator == "-":
        answer = left - right
    elif operator == "*":
        answer = left * right
    elif right == 0:  # remaining operator is "/"
        return "Error: cannot divide by zero."
    else:
        answer = left / right
    return f"{left:g} {operator} {right:g} = {answer:g}"


def unit_converter_tool(value, from_unit, to_unit):
    conversions = {
        ("km", "miles"): lambda v: v * 0.621371,
        ("miles", "km"): lambda v: v / 0.621371,
        ("celsius", "fahrenheit"): lambda v: v * 9 / 5 + 32,
        ("fahrenheit", "celsius"): lambda v: (v - 32) * 5 / 9,
    }
    convert = conversions.get((from_unit, to_unit))
    if convert is None:
        return f"Error: I cannot convert {from_unit} to {to_unit}."
    return f"{value:g} {from_unit} = {convert(value):.2f} {to_unit}"


def word_count_tool(text):
    return f"The text has {len(text.split())} words."


HELP_TEXT = ("I can: add task <text> | show tasks | calculate <a> <+-*/> <b> | "
             "convert <n> <km|miles|celsius|fahrenheit> to <unit> | count words in <text> | bye")


# ---------------------------------------------------------------- agent
@dataclass
class Decision:
    tool: str      # name of the tool to use, or "none" / "stop"
    args: tuple    # arguments for the tool
    reason: str    # why this decision was taken (useful for debugging)


@dataclass
class Agent:
    tasks: list = field(default_factory=list)    # memory: to-do items
    history: list = field(default_factory=list)  # memory: (input, tool) pairs
    finished: bool = False

    def observe(self, raw_input):
        """Clean the raw input into the form the agent reasons about."""
        return raw_input.strip()

    def decide(self, observation):
        """Choose a tool using pattern rules. Order matters: first match wins."""
        if not observation:
            return Decision("none", (), "empty input")
        if re.fullmatch(r"(bye|quit|exit)", observation, re.IGNORECASE):
            return Decision("stop", (), "user ended the session")
        if re.fullmatch(r"help", observation, re.IGNORECASE):
            return Decision("help", (), "user asked for help")

        match = re.fullmatch(r"add task[: ]+(.+)", observation, re.IGNORECASE)
        if match:
            return Decision("add_task", (match.group(1),), "matched 'add task'")
        if re.fullmatch(r"(show|list) (my )?tasks", observation, re.IGNORECASE):
            return Decision("show_tasks", (), "matched 'show tasks'")

        match = re.fullmatch(rf"(?:calculate|what is) ({NUMBER}) ?([+\-*/]) ?({NUMBER})", observation, re.IGNORECASE)
        if match:
            left, operator, right = match.groups()
            return Decision("calculator", (float(left), operator, float(right)), "matched arithmetic request")

        match = re.fullmatch(rf"convert ({NUMBER}) ?(\w+) to (\w+)", observation, re.IGNORECASE)
        if match:
            value, from_unit, to_unit = match.groups()
            return Decision("converter", (float(value), from_unit.lower(), to_unit.lower()), "matched conversion request")

        match = re.fullmatch(r"count words in[: ]+(.+)", observation, re.IGNORECASE)
        if match:
            return Decision("word_count", (match.group(1),), "matched word-count request")

        return Decision("none", (), "no rule matched")

    def act(self, decision):
        """Run the chosen tool and return the response text."""
        if decision.tool == "add_task":
            self.tasks.append(decision.args[0])
            return f"Added task #{len(self.tasks)}: {decision.args[0]}"
        if decision.tool == "show_tasks":
            if not self.tasks:
                return "Your task list is empty."
            return "Tasks: " + "; ".join(f"{i}. {task}" for i, task in enumerate(self.tasks, start=1))
        if decision.tool == "calculator":
            return calculator_tool(*decision.args)
        if decision.tool == "converter":
            return unit_converter_tool(*decision.args)
        if decision.tool == "word_count":
            return word_count_tool(*decision.args)
        if decision.tool == "help":
            return HELP_TEXT
        if decision.tool == "stop":
            self.finished = True
            return "Goodbye!"
        return "I did not understand that. Type 'help' to see what I can do."

    def step(self, raw_input):
        """One full Observe -> Decide -> Act cycle, with the trace printed."""
        observation = self.observe(raw_input)
        decision = self.decide(observation)
        result = self.act(decision)
        self.history.append((observation, decision.tool))
        print(f"Observe: {observation!r}")
        print(f"Decide : tool={decision.tool} ({decision.reason})")
        print(f"Act    : {result}\n")


def run_demo():
    agent = Agent()
    for line in DEMO_FILE.read_text(encoding="utf-8").splitlines():
        agent.step(line)
        if agent.finished:
            break
    print(f"Session summary: {len(agent.history)} requests handled, {len(agent.tasks)} tasks stored.")


def run_interactive():
    agent = Agent()
    print("Simple agent ready. Type 'help' for options.\n")
    while not agent.finished:
        try:
            agent.step(input("You: "))
        except EOFError:
            break


if __name__ == "__main__":
    run_demo() if "--demo" in sys.argv else run_interactive()
