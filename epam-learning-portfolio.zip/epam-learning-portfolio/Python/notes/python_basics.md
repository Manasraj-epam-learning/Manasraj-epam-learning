# Python Basics: Short Notes

Status: in progress. These notes cover what I have learned so far.

## Variables and data types

A variable is a name that refers to a value. Python figures out the type automatically.

```python
name = "Asha"        # str
age = 20             # int
height = 1.62        # float
is_student = True    # bool
```

Check a type with `type(value)`. Convert with `int()`, `float()`, `str()`. Converting bad input (`int("abc")`) raises `ValueError`.

## Operators

| Kind | Operators | Notes |
|------|-----------|-------|
| Arithmetic | `+ - * / // % **` | `/` always gives a float, `//` is floor division, `%` is remainder |
| Comparison | `== != < > <= >=` | Give `True` or `False` |
| Logical | `and or not` | Combine conditions |
| Membership | `in`, `not in` | `"a" in "cat"` is `True` |

## Conditions

```python
if marks >= 90:
    grade = "A"
elif marks >= 75:
    grade = "B"
else:
    grade = "C"
```

Only the first true branch runs. Indentation defines the block.

## Loops

```python
for number in range(1, 4):   # 1, 2, 3 (stop value is excluded)
    print(number)

count = 3
while count > 0:             # repeat while the condition is true
    count -= 1
```

`break` leaves the loop; `continue` skips to the next iteration.

## Functions

```python
def average(numbers):
    """Return the mean of a list of numbers."""
    return sum(numbers) / len(numbers)
```

Functions make code reusable and testable. Use `return` to give back a value, and write a short docstring describing what the function does.

## Basic collections

| Collection | Example | Properties |
|------------|---------|------------|
| list | `[3, 1, 2]` | Ordered, changeable, allows duplicates |
| tuple | `(3, 1, 2)` | Ordered, not changeable |
| set | `{1, 2, 3}` | Unordered, unique items only |
| dict | `{"name": "Asha"}` | Key-value pairs, fast lookup by key |

Useful operations: `append`, `len`, `sorted`, indexing `items[0]`, slicing `items[1:3]`, `dict.get(key, default)`.

## Exception handling

```python
try:
    result = 10 / int(user_text)
except ValueError:
    print("Please enter a number.")
except ZeroDivisionError:
    print("Cannot divide by zero.")
else:
    print(result)       # runs only if no exception happened
finally:
    print("Done")       # always runs
```

Catch specific exceptions rather than a bare `except:`, so real bugs are not hidden. Use `raise ValueError("message")` to signal invalid input from your own functions.

## Good habits I am practising

- Meaningful names (`total_marks`, not `tm`).
- Small functions that do one thing.
- Guarding the demo code with `if __name__ == "__main__":` so a file can be imported without running.
- Testing edge cases: empty input, zero, negative numbers, wrong types.

## Still to learn

File handling, classes and objects, modules and packages, virtual environments, and writing unit tests with `unittest` or `pytest`.
