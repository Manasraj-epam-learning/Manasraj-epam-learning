# Python

**Status: IN PROGRESS**

## Overview

This folder holds my notes and practice programs for Python fundamentals. I am still working through the basics and plan to continue with file handling, classes, modules and testing.

## Concepts covered so far

- Variables, data types and type conversion
- Arithmetic, comparison, logical and membership operators
- Conditions (`if` / `elif` / `else`)
- Loops (`for`, `while`, `break`, `continue`)
- Functions, parameters and return values
- Basic collections: list, tuple, set, dictionary
- Basic exception handling (`try` / `except` / `else` / `finally`, `raise`)

## Folder structure

```
Python/
├── README.md
├── notes/
│   └── python_basics.md
├── code/
│   ├── basics_tour.py              # types, operators, conditions, loops
│   ├── temperature_converter.py    # functions, validation
│   ├── grade_calculator.py         # conditions, lists, error handling
│   ├── number_patterns.py          # loops
│   ├── student_records.py          # dictionaries, sorting
│   ├── safe_calculator.py          # exception handling
│   └── word_counter.py             # strings, dictionaries
├── practice/
│   ├── exercise_1_palindrome.py
│   ├── exercise_2_second_largest.py
│   └── exercise_3_primes.py
└── outputs/                        # saved output of every script
```

## How to run

Requires Python 3.8 or later. Run from inside the `Python` folder:

```bash
python code/basics_tour.py
python code/temperature_converter.py
python code/grade_calculator.py
python code/number_patterns.py
python code/student_records.py
python code/safe_calculator.py
python code/word_counter.py

python practice/exercise_1_palindrome.py
python practice/exercise_2_second_largest.py
python practice/exercise_3_primes.py
```

The practice files contain `assert` tests, so they print "All tests passed." when the solution is correct.

## Expected output (example: `safe_calculator.py`)

```text
'12 + 8'   = 20
'10 / 4'   = 2.5
'7 / 0'    -> Error: cannot divide by zero
'5 ^ 2'    -> Error: unsupported operator '^'
'abc * 3'  -> Error: could not convert string to float: 'abc'
'1 +'      -> Error: use the format: <number> <operator> <number>
```

## Key learning outcomes so far

- I can write small programs using conditions, loops and functions.
- I can store and process data with lists and dictionaries.
- I can validate input and handle errors without the program crashing.
- I am building the habit of testing edge cases such as empty input and invalid values.
