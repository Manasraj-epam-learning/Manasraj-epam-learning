"""Store student marks in a dictionary and rank the students."""


def add_student(records, name, marks):
    if not name.strip():
        raise ValueError("name cannot be empty")
    records[name.strip().title()] = list(marks)


def average_marks(records, name):
    marks = records.get(name.title())
    if marks is None:
        raise KeyError(f"student '{name}' not found")
    return sum(marks) / len(marks) if marks else 0.0


def ranking(records):
    """Return (name, average) pairs, best first."""
    averages = [(name, average_marks(records, name)) for name in records]
    return sorted(averages, key=lambda pair: pair[1], reverse=True)


if __name__ == "__main__":
    records = {}
    add_student(records, "riya", [82, 90, 76])
    add_student(records, "karan", [65, 70, 58])
    add_student(records, "meera", [91, 88, 95])

    for position, (name, average) in enumerate(ranking(records), start=1):
        print(f"{position}. {name:<6} {average:.1f}")

    try:
        average_marks(records, "Zoya")
    except KeyError as error:
        print("Error:", error)
