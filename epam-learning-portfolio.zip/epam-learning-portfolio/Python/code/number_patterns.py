"""Practise loops: multiplication table, star triangle and digit sum."""


def multiplication_table(number, up_to=10):
    for i in range(1, up_to + 1):
        print(f"{number} x {i:>2} = {number * i}")


def print_triangle(rows):
    for row in range(1, rows + 1):
        print("*" * row)


def sum_of_digits(number):
    total = 0
    number = abs(number)
    while number > 0:
        total += number % 10
        number //= 10
    return total


if __name__ == "__main__":
    multiplication_table(7, up_to=5)
    print()
    print_triangle(4)
    print()
    for value in (1234, 9, 0, -507):
        print(f"Sum of digits of {value} = {sum_of_digits(value)}")
