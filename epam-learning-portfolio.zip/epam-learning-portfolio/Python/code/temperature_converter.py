"""Convert temperatures between Celsius, Fahrenheit and Kelvin."""

ABSOLUTE_ZERO_C = -273.15


def celsius_to_fahrenheit(celsius):
    return celsius * 9 / 5 + 32


def fahrenheit_to_celsius(fahrenheit):
    return (fahrenheit - 32) * 5 / 9


def celsius_to_kelvin(celsius):
    if celsius < ABSOLUTE_ZERO_C:
        raise ValueError("temperature cannot be below absolute zero (-273.15 C)")
    return celsius + 273.15


if __name__ == "__main__":
    for celsius in (0, 37, 100, -40):
        print(f"{celsius:>5} C = {celsius_to_fahrenheit(celsius):6.1f} F = {celsius_to_kelvin(celsius):6.2f} K")
    print(f"98.6 F = {fahrenheit_to_celsius(98.6):.1f} C")

    try:
        celsius_to_kelvin(-300)
    except ValueError as error:
        print("Error:", error)
