"""Calculate average marks and a letter grade for a student."""


def letter_grade(average):
    if average >= 90:
        return "A"
    if average >= 75:
        return "B"
    if average >= 60:
        return "C"
    if average >= 40:
        return "D"
    return "F"


def summarize_marks(marks):
    if not marks:
        raise ValueError("marks list is empty")
    if any(mark < 0 or mark > 100 for mark in marks):
        raise ValueError("every mark must be between 0 and 100")
    average = sum(marks) / len(marks)
    return {"average": round(average, 2), "highest": max(marks), "lowest": min(marks),
            "grade": letter_grade(average)}


if __name__ == "__main__":
    for marks in ([88, 92, 79, 95], [55, 62, 48], [], [80, 105]):
        try:
            print(marks, "->", summarize_marks(marks))
        except ValueError as error:
            print(marks, "-> Error:", error)
