"""A quick tour of variables, data types, operators, conditions and loops."""

name = "Asha"
age = 20
height_m = 1.62
is_student = True

for value in (name, age, height_m, is_student):
    print(f"{value!r:<8} is of type {type(value).__name__}")

print("\nOperators with 17 and 5:")
a, b = 17, 5
print(f"  {a} + {b} = {a + b}   {a} / {b} = {a / b}   {a} // {b} = {a // b}")
print(f"  {a} % {b} = {a % b}    {a} ** {b} = {a ** b}")
print(f"  {a} > {b} and {b} > 10 -> {a > b and b > 10}")

print("\nCondition: age group")
if age < 13:
    group = "child"
elif age < 20:
    group = "teenager"
else:
    group = "adult"
print(f"  {name} is {age}, so the group is: {group}")

print("\nLoop: even numbers from 1 to 10")
even_numbers = []
for number in range(1, 11):
    if number % 2 == 0:
        even_numbers.append(number)
print(" ", even_numbers)
