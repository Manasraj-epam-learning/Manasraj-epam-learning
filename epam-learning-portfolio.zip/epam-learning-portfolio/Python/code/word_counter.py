"""Count how often each word appears in a piece of text."""

import string


def count_words(text):
    translation = str.maketrans("", "", string.punctuation)
    words = text.lower().translate(translation).split()
    counts = {}
    for word in words:
        counts[word] = counts.get(word, 0) + 1
    return counts


def top_words(counts, n=3):
    # Sort by count (high to low), then alphabetically so the order is stable.
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:n]


if __name__ == "__main__":
    sample = "Python is easy. Python is fun, and practice makes Python easier!"
    counts = count_words(sample)
    print("Total words :", sum(counts.values()))
    print("Unique words:", len(counts))
    print("Top 3       :", top_words(counts))
    print("Empty text  :", count_words(""))
