"""A small calculator that handles bad input with exception handling."""


def calculate(expression):
    """Evaluate text such as '12 / 4' (number, operator, number)."""
    parts = expression.split()
    if len(parts) != 3:
        raise ValueError("use the format: <number> <operator> <number>")
    left, operator, right = parts
    left, right = float(left), float(right)  # raises ValueError for non-numbers

    if operator == "+":
        return left + right
    if operator == "-":
        return left - right
    if operator == "*":
        return left * right
    if operator == "/":
        return left / right  # raises ZeroDivisionError when right is 0
    raise ValueError(f"unsupported operator '{operator}'")


if __name__ == "__main__":
    for text in ("12 + 8", "10 / 4", "7 / 0", "5 ^ 2", "abc * 3", "1 +"):
        try:
            print(f"{text!r:<10} = {calculate(text):g}")
        except ZeroDivisionError:
            print(f"{text!r:<10} -> Error: cannot divide by zero")
        except ValueError as error:
            print(f"{text!r:<10} -> Error: {error}")
