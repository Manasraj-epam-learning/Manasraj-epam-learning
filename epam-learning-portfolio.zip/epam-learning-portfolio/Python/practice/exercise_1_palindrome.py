"""Exercise 1: Check whether a phrase is a palindrome.

Ignore case, spaces and punctuation: "A man, a plan, a canal: Panama" is a palindrome.
"""


def is_palindrome(text):
    cleaned = [character.lower() for character in text if character.isalnum()]
    return cleaned == cleaned[::-1]


if __name__ == "__main__":
    tests = {"level": True, "A man, a plan, a canal: Panama": True, "python": False, "": True}
    for text, expected in tests.items():
        result = is_palindrome(text)
        assert result == expected, f"failed for {text!r}"
        print(f"{text!r:<35} -> {result}")
    print("All tests passed.")
