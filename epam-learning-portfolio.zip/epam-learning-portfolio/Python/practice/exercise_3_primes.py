"""Exercise 3: List all prime numbers up to n.

A prime is greater than 1 and divisible only by 1 and itself.
"""


def is_prime(number):
    if number < 2:
        return False
    divisor = 2
    while divisor * divisor <= number:  # checking up to the square root is enough
        if number % divisor == 0:
            return False
        divisor += 1
    return True


def primes_up_to(limit):
    return [number for number in range(2, limit + 1) if is_prime(number)]


if __name__ == "__main__":
    print("Primes up to 30:", primes_up_to(30))
    assert primes_up_to(1) == []
    assert primes_up_to(2) == [2]
    assert primes_up_to(30) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    print("All tests passed.")
