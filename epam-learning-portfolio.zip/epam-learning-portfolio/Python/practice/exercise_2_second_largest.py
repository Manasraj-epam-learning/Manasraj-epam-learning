"""Exercise 2: Find the second largest distinct number in a list.

[4, 9, 9, 2] -> 4 (duplicates of the largest do not count as the second largest).
Return None when no second distinct value exists.
"""


def second_largest(numbers):
    largest = second = None
    for number in numbers:
        if largest is None or number > largest:
            largest, second = number, largest
        elif number != largest and (second is None or number > second):
            second = number
    return second


if __name__ == "__main__":
    tests = [([4, 9, 9, 2], 4), ([10, 5], 5), ([7, 7, 7], None), ([], None), ([-3, -1, -2], -2)]
    for numbers, expected in tests:
        result = second_largest(numbers)
        assert result == expected, f"failed for {numbers}"
        print(f"{numbers!s:<14} -> {result}")
    print("All tests passed.")
