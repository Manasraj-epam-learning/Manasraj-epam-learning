"""Exercise 6: Why accuracy alone can be misleading on imbalanced data.

Task: a dataset has 95 legitimate transactions and 5 fraudulent ones. Show that a
"model" that always predicts "legitimate" gets 95% accuracy yet catches no fraud,
and explain which metric exposes the problem.
"""

y_true = [0] * 95 + [1] * 5   # 1 = fraud
y_pred = [0] * 100            # always predicts "not fraud"

accuracy = sum(t == p for t, p in zip(y_true, y_pred)) / len(y_true)
frauds_caught = sum(t == 1 and p == 1 for t, p in zip(y_true, y_pred))
recall = frauds_caught / sum(y_true)

print(f"Accuracy : {accuracy:.2f}")
print(f"Recall   : {recall:.2f}  ({frauds_caught} of {sum(y_true)} frauds caught)")
print("Lesson: on imbalanced data, check recall/precision/F1, not accuracy alone.")
