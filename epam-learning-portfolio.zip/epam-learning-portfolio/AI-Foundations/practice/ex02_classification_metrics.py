"""Exercise 2: Compute accuracy, precision, recall and F1 from predictions.

Task: given true and predicted labels (1 = positive, 0 = negative), build the
confusion matrix counts and the four metrics. Handle division by zero.
"""


def classification_metrics(y_true, y_pred):
    if len(y_true) != len(y_pred) or not y_true:
        raise ValueError("y_true and y_pred must be non-empty and of equal length")
    tp = sum(t == 1 and p == 1 for t, p in zip(y_true, y_pred))
    fp = sum(t == 0 and p == 1 for t, p in zip(y_true, y_pred))
    fn = sum(t == 1 and p == 0 for t, p in zip(y_true, y_pred))
    tn = len(y_true) - tp - fp - fn
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"TP": tp, "FP": fp, "FN": fn, "TN": tn,
            "accuracy": (tp + tn) / len(y_true), "precision": precision, "recall": recall, "f1": f1}


if __name__ == "__main__":
    y_true = [1, 0, 1, 1, 0, 0, 1, 0, 1, 0]
    y_pred = [1, 0, 0, 1, 0, 1, 1, 0, 1, 0]
    for name, value in classification_metrics(y_true, y_pred).items():
        print(f"{name:<9}: {value:.2f}" if isinstance(value, float) else f"{name:<9}: {value}")

    # Edge case: the model never predicts the positive class.
    print("\nNever predicts positive:", classification_metrics([1, 0, 1], [0, 0, 0]))
