"""Exercise 1: Where does a system sit in the AI / ML / DL / GenAI hierarchy?

Task: write categorize(learns_from_data, uses_neural_network, generates_new_content)
that returns the most specific category, then test it on real-world examples.
"""


def categorize(learns_from_data, uses_neural_network, generates_new_content):
    if not learns_from_data:
        return "Rule-based / symbolic AI (not machine learning)"
    if generates_new_content and uses_neural_network:
        return "Generative AI (deep-learning based)"
    if generates_new_content:
        return "Generative model (classical ML)"
    if uses_neural_network:
        return "Deep learning"
    return "Classical machine learning"


EXAMPLES = [
    # (description, learns_from_data, uses_neural_network, generates_new_content)
    ("Chess engine with hand-written evaluation rules and search", False, False, False),
    ("House price prediction with linear regression", True, False, False),
    ("Spam filter trained with Naive Bayes", True, False, False),
    ("Image classifier using a convolutional neural network", True, True, False),
    ("Chatbot built on a large language model", True, True, True),
    ("Text generator using word-pair (Markov chain) statistics", True, False, True),
]

if __name__ == "__main__":
    for description, learns, neural, generates in EXAMPLES:
        print(f"{description}\n    -> {categorize(learns, neural, generates)}")
