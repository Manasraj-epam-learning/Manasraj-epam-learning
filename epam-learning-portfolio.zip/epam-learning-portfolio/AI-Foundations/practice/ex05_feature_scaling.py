"""Exercise 5: Feature scaling (min-max and z-score).

Task: implement both scalers. Handle the edge case where all values are equal.
Why it matters: features with large ranges (salary) can dominate distance-based
or gradient-based algorithms over features with small ranges (age).
"""


def min_max_scale(values):
    low, high = min(values), max(values)
    if high == low:
        return [0.0 for _ in values]  # no spread -> nothing to scale
    return [(v - low) / (high - low) for v in values]


def z_score_scale(values):
    mean = sum(values) / len(values)
    std = (sum((v - mean) ** 2 for v in values) / len(values)) ** 0.5
    if std == 0:
        return [0.0 for _ in values]
    return [(v - mean) / std for v in values]


if __name__ == "__main__":
    ages = [21, 25, 30, 35, 60]
    salaries = [20000, 30000, 45000, 60000, 150000]
    for name, values in (("age", ages), ("salary", salaries)):
        print(f"{name}")
        print("  min-max:", [round(v, 2) for v in min_max_scale(values)])
        print("  z-score:", [round(v, 2) for v in z_score_scale(values)])
    print("constant column:", min_max_scale([5, 5, 5]), z_score_scale([5, 5, 5]))
