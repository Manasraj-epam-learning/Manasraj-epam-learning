"""Exercise 3: Implement a reproducible train/test split.

Task: split a list into train and test parts after shuffling. The same seed must
always give the same split. Validate the inputs and prove that no item is lost
or duplicated.
"""

import random


def train_test_split(items, test_ratio=0.2, seed=0):
    if not 0 < test_ratio < 1:
        raise ValueError("test_ratio must be between 0 and 1")
    if len(items) < 2:
        raise ValueError("need at least 2 items to split")
    shuffled = list(items)  # copy so the caller's list is not modified
    random.Random(seed).shuffle(shuffled)
    n_test = max(1, int(len(shuffled) * test_ratio))
    return shuffled[n_test:], shuffled[:n_test]


if __name__ == "__main__":
    data = list(range(1, 11))
    train, test = train_test_split(data, test_ratio=0.3, seed=1)
    print("train:", train)
    print("test :", test)

    assert sorted(train + test) == data, "items lost or duplicated"
    assert train_test_split(data, 0.3, seed=1) == (train, test), "not reproducible"
    print("Checks passed: no items lost, same seed gives same split.")

    try:
        train_test_split(data, test_ratio=1.5)
    except ValueError as error:
        print("Invalid ratio rejected:", error)
