"""Exercise 4: See overfitting with k-nearest-neighbours on noisy data.

Task: build a 1-D dataset where the label is (x > 5) but 15% of labels are
flipped (noise). Compare k=1 (memorises every point, noise included) with k=15
(smoother). Compare train and test accuracy, and repeat over many seeds because
a single random split can mislead.
"""

import random


def make_data(n, rng):
    points = []
    for _ in range(n):
        x = rng.uniform(0, 10)
        label = int(x > 5)
        if rng.random() < 0.15:  # noise: flip the label
            label = 1 - label
        points.append((x, label))
    return points


def knn_predict(train_points, x, k):
    nearest = sorted(train_points, key=lambda point: abs(point[0] - x))[:k]
    votes = sum(label for _, label in nearest)
    return int(votes * 2 > k)


def accuracy(train_points, eval_points, k):
    correct = sum(knn_predict(train_points, x, k) == label for x, label in eval_points)
    return correct / len(eval_points)


def run_experiment(seed):
    rng = random.Random(seed)
    train_points, test_points = make_data(60, rng), make_data(200, rng)
    return {k: (accuracy(train_points, train_points, k), accuracy(train_points, test_points, k))
            for k in (1, 15)}


if __name__ == "__main__":
    single = run_experiment(seed=7)
    print("Single run (seed=7)")
    for k, (train_acc, test_acc) in single.items():
        print(f"  k={k:<2}: train accuracy={train_acc:.2f}  test accuracy={test_acc:.2f}")

    runs = [run_experiment(seed) for seed in range(20)]
    print("\nAverage over 20 different seeds")
    for k in (1, 15):
        train_avg = sum(run[k][0] for run in runs) / len(runs)
        test_avg = sum(run[k][1] for run in runs) / len(runs)
        print(f"  k={k:<2}: train accuracy={train_avg:.2f}  test accuracy={test_avg:.2f}")
    print("\nk=1 scores 1.00 on training data (each point is its own neighbour) but does worse on new data.")
