"""Linear regression trained with gradient descent, written from scratch.

Goal: predict an exam score from the hours a student studied.

This IS a (very small) machine-learning model: its two parameters, the slope
and the intercept, are learned from data instead of being written by hand.
The dataset is tiny and hand-made, so the numbers illustrate the workflow;
they say nothing about real students.
"""

import random

HOURS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 0.5]
SCORES = [41, 46, 56, 59, 68, 72, 82, 85, 92, 99, 43, 50, 57, 64, 70, 75, 85, 88, 96, 37]


def train_test_split(xs, ys, test_ratio=0.2, seed=42):
    """Shuffle the data reproducibly and split it into train and test parts."""
    if len(xs) != len(ys):
        raise ValueError("xs and ys must have the same length")
    if not 0 < test_ratio < 1:
        raise ValueError("test_ratio must be between 0 and 1")
    indices = list(range(len(xs)))
    random.Random(seed).shuffle(indices)
    n_test = max(1, int(len(xs) * test_ratio))
    test_idx, train_idx = indices[:n_test], indices[n_test:]
    return (
        [xs[i] for i in train_idx], [ys[i] for i in train_idx],
        [xs[i] for i in test_idx], [ys[i] for i in test_idx],
    )


def predict(slope, intercept, x):
    return slope * x + intercept


def mean_squared_error(xs, ys, slope, intercept):
    """Average of squared differences between predictions and true values."""
    return sum((predict(slope, intercept, x) - y) ** 2 for x, y in zip(xs, ys)) / len(xs)


def train(xs, ys, learning_rate=0.01, epochs=4000, log_every=1000):
    """Learn slope and intercept by repeatedly stepping against the gradient of the MSE."""
    slope, intercept = 0.0, 0.0
    n = len(xs)
    for epoch in range(1, epochs + 1):
        grad_slope = grad_intercept = 0.0
        for x, y in zip(xs, ys):
            error = predict(slope, intercept, x) - y
            grad_slope += 2 * error * x / n
            grad_intercept += 2 * error / n
        slope -= learning_rate * grad_slope
        intercept -= learning_rate * grad_intercept
        if epoch == 1 or epoch % log_every == 0:
            loss = mean_squared_error(xs, ys, slope, intercept)
            print(f"  epoch {epoch:>5}: train MSE = {loss:8.3f}  (slope={slope:.3f}, intercept={intercept:.3f})")
    return slope, intercept


def least_squares(xs, ys):
    """Exact closed-form solution, used only to check that gradient descent converged."""
    mean_x, mean_y = sum(xs) / len(xs), sum(ys) / len(ys)
    slope = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / sum((x - mean_x) ** 2 for x in xs)
    return slope, mean_y - slope * mean_x


def main():
    train_x, train_y, test_x, test_y = train_test_split(HOURS, SCORES)
    print(f"Samples: {len(HOURS)} total -> {len(train_x)} train, {len(test_x)} test\n")

    print("Training with gradient descent:")
    slope, intercept = train(train_x, train_y)

    exact_slope, exact_intercept = least_squares(train_x, train_y)
    print(f"\nLearned    : score = {slope:.3f} * hours + {intercept:.3f}")
    print(f"Closed form: score = {exact_slope:.3f} * hours + {exact_intercept:.3f}  (sanity check)")

    mean_baseline = sum(train_y) / len(train_y)
    baseline_mse = sum((mean_baseline - y) ** 2 for y in test_y) / len(test_y)
    print(f"\nTest MSE of the model            : {mean_squared_error(test_x, test_y, slope, intercept):.3f}")
    print(f"Test MSE of 'always predict mean': {baseline_mse:.3f}  (a model should beat this)")

    for hours in (2, 6):
        print(f"Prediction for {hours} hours of study: {predict(slope, intercept, hours):.1f}")


if __name__ == "__main__":
    main()
