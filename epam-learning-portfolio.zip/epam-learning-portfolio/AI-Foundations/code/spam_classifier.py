"""Mini project: spam vs. ham classifier using Naive Bayes, written from scratch.

Two approaches are compared on the same unseen test messages:
  1. A rule-based filter  -> hand-written keyword rules. NOT machine learning.
  2. Naive Bayes          -> word statistics LEARNED from labelled examples. This is ML.

The dataset (data/messages.csv) is 40 short hand-written messages. It is far too
small for real use; the goal is to show the full ML workflow end to end:
load data -> split -> train -> predict -> evaluate.
"""

import csv
import math
import random
import re
from collections import Counter
from pathlib import Path

DATA_PATH = Path(__file__).parent / "data" / "messages.csv"
POSITIVE_LABEL = "spam"
SPAM_KEYWORDS = {"free", "win", "winner", "prize", "claim", "urgent", "click", "offer", "cash", "lottery"}


def tokenize(text):
    """Lowercase the text and split it into words."""
    return re.findall(r"[a-z0-9']+", text.lower())


def load_messages(path=DATA_PATH):
    with open(path, newline="", encoding="utf-8") as file:
        rows = list(csv.DictReader(file))
    return [row["text"] for row in rows], [row["label"] for row in rows]


def stratified_split(texts, labels, test_ratio=0.25, seed=42):
    """Split so that train and test keep the same spam/ham proportion."""
    rng = random.Random(seed)
    train, test = [], []
    for label in sorted(set(labels)):
        items = [(t, l) for t, l in zip(texts, labels) if l == label]
        rng.shuffle(items)
        n_test = max(1, round(len(items) * test_ratio))
        test.extend(items[:n_test])
        train.extend(items[n_test:])
    return [t for t, _ in train], [l for _, l in train], [t for t, _ in test], [l for _, l in test]


class NaiveBayesClassifier:
    """Multinomial Naive Bayes with Laplace (add-one) smoothing."""

    def fit(self, texts, labels):
        self.classes = sorted(set(labels))
        self.class_counts = Counter(labels)
        self.word_counts = {label: Counter() for label in self.classes}
        for text, label in zip(texts, labels):
            self.word_counts[label].update(tokenize(text))
        self.vocabulary = set().union(*self.word_counts.values())
        self.total_words = {label: sum(c.values()) for label, c in self.word_counts.items()}
        self.n_documents = len(texts)
        return self

    def _word_log_prob(self, word, label):
        # Add-one smoothing avoids log(0) for words never seen in this class.
        count = self.word_counts[label][word]
        return math.log((count + 1) / (self.total_words[label] + len(self.vocabulary)))

    def _log_score(self, tokens, label):
        score = math.log(self.class_counts[label] / self.n_documents)  # prior
        for token in tokens:
            if token in self.vocabulary:  # unseen words carry no information
                score += self._word_log_prob(token, label)
        return score

    def predict(self, text):
        tokens = tokenize(text)
        return max(self.classes, key=lambda label: self._log_score(tokens, label))

    def most_indicative_words(self, label, other_label, top_n=5):
        """Words whose probability is highest in `label` relative to `other_label`."""
        ratios = {
            word: self._word_log_prob(word, label) - self._word_log_prob(word, other_label)
            for word in self.vocabulary
        }
        # Tie-break alphabetically so the result is the same on every run.
        return sorted(ratios, key=lambda word: (-ratios[word], word))[:top_n]


def rule_based_predict(text):
    """Hand-written rule: any suspicious keyword -> spam. No learning involved."""
    return "spam" if SPAM_KEYWORDS & set(tokenize(text)) else "ham"


def evaluate(true_labels, predicted_labels):
    """Return confusion counts and the standard classification metrics."""
    pairs = list(zip(true_labels, predicted_labels))
    tp = sum(t == POSITIVE_LABEL and p == POSITIVE_LABEL for t, p in pairs)
    fp = sum(t != POSITIVE_LABEL and p == POSITIVE_LABEL for t, p in pairs)
    fn = sum(t == POSITIVE_LABEL and p != POSITIVE_LABEL for t, p in pairs)
    tn = len(pairs) - tp - fp - fn
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "accuracy": (tp + tn) / len(pairs), "precision": precision, "recall": recall, "f1": f1}


def print_report(name, metrics):
    print(name)
    print(f"  confusion: TP={metrics['tp']} FP={metrics['fp']} FN={metrics['fn']} TN={metrics['tn']}")
    print(f"  accuracy={metrics['accuracy']:.2f}  precision={metrics['precision']:.2f}  "
          f"recall={metrics['recall']:.2f}  f1={metrics['f1']:.2f}")


def main():
    texts, labels = load_messages()
    train_x, train_y, test_x, test_y = stratified_split(texts, labels)
    print(f"Loaded {len(texts)} messages -> {len(train_x)} train, {len(test_x)} test\n")

    model = NaiveBayesClassifier().fit(train_x, train_y)
    print_report("Naive Bayes (learned from data)", evaluate(test_y, [model.predict(t) for t in test_x]))
    print_report("Keyword rules (hand-written, not ML)", evaluate(test_y, [rule_based_predict(t) for t in test_x]))
    print(f"\nNote: only {len(test_x)} test messages, so one mistake changes the scores a lot.")

    print("\nWords the model links most strongly to spam:", ", ".join(model.most_indicative_words("spam", "ham")))

    print("\nPredictions on new messages:")
    new_messages = [
        "Claim your free prize now",
        "Can you send the python notes tomorrow",
        "Are you free for the sprint review",
        "",
    ]
    for message in new_messages:
        print(f"  model: {model.predict(message):<4} | rules: {rule_based_predict(message):<4} | {message!r}")


if __name__ == "__main__":
    main()
