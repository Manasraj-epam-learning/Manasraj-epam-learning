# AI Foundations

**Status: COMPLETED**

## Overview

This topic covers the core ideas behind Artificial Intelligence: what AI is, how it relates to machine learning, deep learning and generative AI, how a machine learning project is organised, and how models are evaluated. The notes are paired with small Python programs that implement the ideas without external libraries, so every step is visible.

## Educational demonstration vs. trained model

| Program | What it is |
|---------|-----------|
| `code/linear_regression_demo.py` | A **real trained ML model**. Slope and intercept are learned from data by gradient descent. |
| `code/spam_classifier.py` | Contains **two** things: a Naive Bayes classifier (a **real trained ML model**) and a keyword filter (a **hand-written rule system, not ML**), compared on the same test data. |
| `practice/` exercises | Educational demonstrations of individual concepts (metrics, splitting, overfitting, scaling). |

The datasets are tiny and hand-made. They show the workflow, but the scores are not evidence of real-world performance.

## Concepts covered

- Definition of AI, narrow AI vs. AGI
- Relationship between AI, ML, deep learning and generative AI
- Rule-based programming vs. machine learning
- Supervised, unsupervised, reinforcement and self-supervised learning
- The ML workflow from problem definition to monitoring
- Features, labels, parameters, hyperparameters, loss, gradient descent
- Train / validation / test split, overfitting and underfitting
- Evaluation metrics: accuracy, precision, recall, F1
- Neural networks, LLMs, tokens, prompts, hallucination (conceptual)
- Limitations, bias and responsible AI

## Folder structure

```
AI-Foundations/
├── README.md
├── notes/
│   ├── concepts.md                 # main concept notes
│   └── terminology.md              # glossary of key terms
├── code/
│   ├── linear_regression_demo.py   # trained model: regression
│   ├── spam_classifier.py          # mini project: Naive Bayes vs. rules
│   └── data/
│       └── messages.csv            # 40 hand-written labelled messages
├── practice/
│   ├── ex01_classify_ai_systems.py
│   ├── ex02_classification_metrics.py
│   ├── ex03_train_test_split.py
│   ├── ex04_overfitting_demo.py
│   ├── ex05_feature_scaling.py
│   └── ex06_accuracy_paradox.py
└── outputs/                        # saved output of every script
```

## How to run

Requires Python 3.8 or later. No packages need to be installed. Run from inside the `AI-Foundations` folder:

```bash
python code/linear_regression_demo.py
python code/spam_classifier.py

python practice/ex01_classify_ai_systems.py
python practice/ex02_classification_metrics.py
python practice/ex03_train_test_split.py
python practice/ex04_overfitting_demo.py
python practice/ex05_feature_scaling.py
python practice/ex06_accuracy_paradox.py
```

## Practice exercises

| File | Task | Skill practised |
|------|------|-----------------|
| `ex01_classify_ai_systems.py` | Place systems in the AI / ML / DL / GenAI hierarchy | Core terminology |
| `ex02_classification_metrics.py` | Compute accuracy, precision, recall, F1 | Model evaluation |
| `ex03_train_test_split.py` | Reproducible train/test split with validation | Data handling |
| `ex04_overfitting_demo.py` | Compare k=1 and k=15 nearest neighbours on noisy data | Overfitting |
| `ex05_feature_scaling.py` | Min-max and z-score scaling | Data preparation |
| `ex06_accuracy_paradox.py` | Show why accuracy misleads on imbalanced data | Choosing metrics |

## Expected output

### Linear regression (`outputs/linear_regression_demo_output.txt`)

```text
Samples: 20 total -> 16 train, 4 test

Training with gradient descent:
  epoch     1: train MSE =  445.008  (slope=8.839, intercept=1.397)
  epoch  1000: train MSE =    1.610  (slope=6.546, intercept=33.786)
  epoch  2000: train MSE =    1.578  (slope=6.494, intercept=34.159)
  epoch  3000: train MSE =    1.578  (slope=6.493, intercept=34.164)
  epoch  4000: train MSE =    1.578  (slope=6.493, intercept=34.164)

Learned    : score = 6.493 * hours + 34.164
Closed form: score = 6.493 * hours + 34.164  (sanity check)

Test MSE of the model            : 0.831
Test MSE of 'always predict mean': 272.203  (a model should beat this)
Prediction for 2 hours of study: 47.1
Prediction for 6 hours of study: 73.1
```

The learned line matches the exact closed-form solution, which confirms that gradient descent converged. The test set has only 4 samples, so the test error is a rough indication.

### Spam classifier (`outputs/spam_classifier_output.txt`)

```text
Loaded 40 messages -> 30 train, 10 test

Naive Bayes (learned from data)
  confusion: TP=5 FP=1 FN=0 TN=4
  accuracy=0.90  precision=0.83  recall=1.00  f1=0.91
Keyword rules (hand-written, not ML)
  confusion: TP=4 FP=0 FN=1 TN=5
  accuracy=0.90  precision=1.00  recall=0.80  f1=0.89

Note: only 10 test messages, so one mistake changes the scores a lot.

Words the model links most strongly to spam: now, claim, free, a, click

Predictions on new messages:
  model: spam | rules: spam | 'Claim your free prize now'
  model: ham  | rules: ham  | 'Can you send the python notes tomorrow'
  model: ham  | rules: spam | 'Are you free for the sprint review'
  model: ham  | rules: ham  | ''
```

Observations: on this tiny test set both approaches score the same accuracy, so no winner should be claimed. The more instructive result is the message "Are you free for the sprint review": the keyword rule flags it as spam because of the word "free", while the trained model uses the words around it and gets it right. That is a single example, not a benchmark. Also notice that the list of top spam words contains "a": with only 40 messages the model picks up accidental patterns, which is a small-scale example of why more and better data matters.

## Key learning outcomes

- I can explain how AI, ML, deep learning and generative AI relate, and why not all AI is machine learning.
- I can describe the machine learning workflow and implement it end to end on a small problem.
- I understand how a model learns (loss function, gradient descent) and implemented it from scratch.
- I can evaluate a classifier with a confusion matrix and explain precision vs. recall.
- I understand overfitting, why test data must stay unseen, and why accuracy can mislead.
- I can distinguish a hand-written rule system from a model that learns from data.
