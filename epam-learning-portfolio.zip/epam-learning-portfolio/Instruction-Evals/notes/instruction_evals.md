# Instruction Evals: Short Notes

Status: in progress. These are introductory notes.

## What is instruction evaluation?

Instruction evaluation (also called instruction-following evaluation) checks whether a response did **exactly what the instructions asked**, especially explicit and verifiable requirements such as:

- "Answer in at most 50 words."
- "Give exactly 3 bullet points."
- "Do not use the word 'very'."
- "Return only valid JSON with the keys `name` and `role`."
- "Start with 'Today' and end with a question."

These constraints can be checked by a program, so the result is a clear pass or fail with a reason.

## Prompt evaluation vs. instruction-following evaluation

| | Prompt evaluation | Instruction-following evaluation |
|---|---|---|
| Main question | Is this prompt, and the response it produces, good overall? | Did the response obey the specific instructions? |
| What is judged | Relevance, accuracy, completeness, clarity, tone, plus adherence | Mostly format and constraints |
| Typical result | A score across several criteria, often needing judgement | Pass/fail per constraint |
| Objectivity | Partly subjective | Mostly objective and automatable |
| Example finding | "The answer is on topic but misses one point" | "The answer has 4 bullets, but 3 were required" |

They overlap (instruction adherence is one of the four criteria in `Prompt-Evaluation`), but they are not the same. A response can follow every instruction and still be a poor answer, and a good answer can still break a formatting rule.

## Basic evaluation criteria

| Constraint type | Example instruction | How it is checked |
|-----------------|--------------------|-------------------|
| Length | "At most 40 words" | Count words |
| Required content | "Mention sprint and backlog" | Whole-word search |
| Forbidden content | "Do not use the word function" | Whole-word search |
| Start / end | "Begin with Today", "End with a question" | Compare the first/last characters |
| Count | "Exactly 3 bullets", "2 sentences" | Count bullet lines / split sentences |
| Case | "All lowercase" | Compare with `.lower()` |
| Structure | "Valid JSON with keys name and role" | Parse with `json.loads` |

## How my implementation works

`code/instruction_checker.py` stores each instruction as a list of constraints, for example `{"type": "max_words", "value": 40}`. A dictionary maps each constraint type to a small checking function that returns `(passed, detail)`. The program runs every check, prints each result with its reason, and reports how many constraints were followed. Adding a new constraint type means writing one function and adding it to the dictionary.

## Limitations

- **Quality is not measured.** `limitation_follows_but_useless` follows every constraint but says nothing useful.
- **Whole-word matching is strict.** Searching for "sprint" does not match "sprints"; a stemmer or regex would be needed for that.
- **Sentence counting is a heuristic.** Abbreviations ("e.g.", "Dr.") or decimals can confuse the splitter.
- **Only explicit constraints are covered.** Vague instructions such as "be friendly" or "explain simply" cannot be checked with simple code.
- **Partial credit is not weighted.** Every constraint counts the same.

## What I want to learn next

Writing instructions that are specific enough to be checkable, combining automated checks with human review for vague instructions, and using a model as a judge for tone and style.
