"""Check whether a response follows explicit, checkable instructions.

Each instruction is written as a list of constraints, for example
{"type": "max_words", "value": 40}. Every check returns (passed, detail).
Only things that can be verified mechanically are checked: length, format,
required or forbidden words, start/end text, JSON structure.
Whether the answer is correct or useful is NOT checked.
"""

import json
import re
import sys
from pathlib import Path

TEST_CASES_PATH = Path(__file__).parent.parent / "examples" / "test_cases.json"
BULLET_PATTERN = re.compile(r"^\s*(?:[-*\u2022])\s+")


def has_word(text, word):
    return re.search(rf"\b{re.escape(word.lower())}\b", text.lower()) is not None


def check_max_words(response, limit):
    count = len(response.split())
    return count <= limit, f"{count} words (limit {limit})"


def check_min_words(response, minimum):
    count = len(response.split())
    return count >= minimum, f"{count} words (minimum {minimum})"


def check_must_include(response, words):
    missing = [word for word in words if not has_word(response, word)]
    return not missing, "all present" if not missing else f"missing: {', '.join(missing)}"


def check_must_not_include(response, words):
    found = [word for word in words if has_word(response, word)]
    return not found, "none used" if not found else f"forbidden word used: {', '.join(found)}"


def check_starts_with(response, prefix):
    return response.strip().startswith(prefix), f"response begins with {response.strip()[:15]!r}"


def check_ends_with(response, suffix):
    return response.strip().endswith(suffix), f"response ends with {response.strip()[-15:]!r}"


def check_bullet_count(response, expected):
    count = sum(bool(BULLET_PATTERN.match(line)) for line in response.splitlines())
    return count == expected, f"{count} bullets (expected {expected})"


def check_sentence_count(response, expected):
    # Heuristic: split after . ! or ?  (abbreviations such as "e.g." can confuse it)
    sentences = [part for part in re.split(r"(?<=[.!?])\s+", response.strip()) if part]
    return len(sentences) == expected, f"{len(sentences)} sentences (expected {expected})"


def check_all_lowercase(response, _value):
    return response == response.lower(), "all lowercase" if response == response.lower() else "contains uppercase letters"


def check_valid_json_with_keys(response, keys):
    try:
        data = json.loads(response)
    except json.JSONDecodeError:
        return False, "not valid JSON (extra text around it also fails)"
    if not isinstance(data, dict):
        return False, "JSON is not an object"
    missing = [key for key in keys if key not in data]
    return not missing, "valid JSON with all keys" if not missing else f"missing keys: {', '.join(missing)}"


CHECKS = {
    "max_words": check_max_words,
    "min_words": check_min_words,
    "must_include": check_must_include,
    "must_not_include": check_must_not_include,
    "starts_with": check_starts_with,
    "ends_with": check_ends_with,
    "bullet_count": check_bullet_count,
    "sentence_count": check_sentence_count,
    "all_lowercase": check_all_lowercase,
    "valid_json_with_keys": check_valid_json_with_keys,
}


def evaluate_response(response, constraints):
    """Run every constraint and return a list of (type, passed, detail)."""
    results = []
    for constraint in constraints:
        check = CHECKS.get(constraint["type"])
        if check is None:
            raise ValueError(f"unknown constraint type: {constraint['type']}")
        passed, detail = check(response, constraint["value"])
        results.append((constraint["type"], passed, detail))
    return results


def main():
    cases = json.loads(TEST_CASES_PATH.read_text(encoding="utf-8"))
    mismatches = 0
    for case in cases:
        results = evaluate_response(case["response"], case["constraints"])
        passed_count = sum(passed for _, passed, _ in results)
        all_followed = passed_count == len(results)
        matches = all_followed == case["expected_all_followed"]
        mismatches += not matches

        print(f"[{case['id']}]")
        print(f"  Instruction: {case['instruction']}")
        for name, passed, detail in results:
            print(f"    {'PASS' if passed else 'FAIL'}  {name}: {detail}")
        print(f"  Followed {passed_count}/{len(results)} constraints -> "
              f"{'ALL FOLLOWED' if all_followed else 'NOT FULLY FOLLOWED'} "
              f"({'as expected' if matches else 'UNEXPECTED'})")
        if "note" in case:
            print(f"  Note: {case['note']}")
        print()

    print(f"{len(cases) - mismatches}/{len(cases)} test cases behaved as expected.")
    return 1 if mismatches else 0


if __name__ == "__main__":
    sys.exit(main())
