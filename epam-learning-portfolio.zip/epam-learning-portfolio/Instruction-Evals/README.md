# Instruction Evals

**Status: IN PROGRESS**

## Overview

Instruction evaluation checks whether a response followed explicit, verifiable instructions: word limits, number of bullets, required or forbidden words, start and end text, valid JSON and similar. This folder has introductory notes and a small Python checker.

## Concepts covered so far

- What instruction-following evaluation is
- How it differs from prompt evaluation
- Basic criteria: length, required/forbidden content, start/end, counts, case, structure
- Limitations: it checks compliance, not quality

## Folder structure

```
Instruction-Evals/
├── README.md
├── notes/
│   └── instruction_evals.md
├── code/
│   └── instruction_checker.py   # constraint checker (standard library only)
└── examples/
    ├── test_cases.json          # 7 test cases
    └── sample_output.txt        # output of the checker
```

## How it works

Each test case lists its instruction, a response and a list of constraints such as `{"type": "max_words", "value": 40}`. A dictionary maps each constraint type to a small function that returns pass or fail with a reason. The program prints each result and tells whether the response followed all constraints. It also compares the outcome with `expected_all_followed` and exits with an error code if a case behaves unexpectedly, so it works as a basic test.

Supported constraint types: `max_words`, `min_words`, `must_include`, `must_not_include`, `starts_with`, `ends_with`, `bullet_count`, `sentence_count`, `all_lowercase`, `valid_json_with_keys`.

## How to run

Requires Python 3.8 or later. Run from inside the `Instruction-Evals` folder:

```bash
python code/instruction_checker.py
```

## Expected output (shortened)

```text
[all_followed]
  Instruction: Explain recursion in at most 40 words. Do not use the word 'function'. End with a question.
    PASS  max_words: 28 words (limit 40)
    PASS  must_not_include: none used
    PASS  ends_with: response ends with 'hat make sense?'
  Followed 3/3 constraints -> ALL FOLLOWED (as expected)
...
[bullet_count_and_case_wrong]
  Instruction: List exactly 3 benefits of Agile as bullet points, all in lowercase.
    FAIL  bullet_count: 4 bullets (expected 3)
    FAIL  all_lowercase: contains uppercase letters
  Followed 0/2 constraints -> NOT FULLY FOLLOWED (as expected)
...
[limitation_follows_but_useless]
  Instruction: Describe Scrum in at most 15 words and mention 'sprint' and 'backlog'.
    PASS  max_words: 6 words (limit 15)
    PASS  must_include: all present
  Followed 2/2 constraints -> ALL FOLLOWED (as expected)
  Note: LIMITATION: every constraint is satisfied, yet the response does not describe Scrum. Instruction checks do not measure quality.

7/7 test cases behaved as expected.
```

The full output is in `examples/sample_output.txt`.

## Key learning outcomes so far

- I can turn an instruction into small, checkable constraints.
- I can explain the difference between instruction following and overall answer quality.
- I know the weaknesses of simple checks (strict word matching, heuristic sentence counting).
- I understand that vague instructions need human or model-based review.
