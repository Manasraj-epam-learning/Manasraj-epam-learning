# Scrum Fundamentals

Scrum is a lightweight framework in which a small team delivers a usable product in short cycles called **Sprints**. The descriptions below follow the Scrum Guide (2020 edition). Timeboxes are maximums for a one-month Sprint; shorter Sprints have shorter events.

## Scrum Team (roles)

| Role | Responsibility |
|------|----------------|
| **Product Owner** | Maximises the value of the product; owns and orders the Product Backlog; decides what is built and in which order. |
| **Scrum Master** | Helps the team understand and use Scrum, removes impediments, and coaches the team. Serves the team; is not a manager or a project manager. |
| **Developers** | Everyone who builds the product increment: programmers, testers, designers. They plan the work and are accountable for quality. |

The team is self-managing: it decides internally who does what and how.

## Scrum events

| Event | Purpose | Timebox (1-month Sprint) |
|-------|---------|--------------------------|
| **Sprint** | A fixed-length cycle (one month or less) in which a usable Increment is created. The container for all other events. | 1 month max (commonly 1-2 weeks) |
| **Sprint Planning** | The team decides *why* the Sprint is valuable (Sprint Goal), *what* can be done (items from the Product Backlog) and *how* it will be done (the plan). | 8 hours max |
| **Daily Scrum** | A short meeting for Developers to inspect progress towards the Sprint Goal and adapt the plan for the next 24 hours. Same time and place every day. | 15 minutes |
| **Sprint Review** | The team and stakeholders inspect the Increment, discuss what was achieved and adapt the Product Backlog based on feedback. It is a working session, not just a demo. | 4 hours max |
| **Sprint Retrospective** | The team inspects how the last Sprint went (people, process, tools, Definition of Done) and agrees improvements. | 3 hours max |

A Sprint's goal does not change during the Sprint. Scope can be clarified and renegotiated with the Product Owner as more is learned, but the Sprint is not cancelled or extended for new requests.

## Scrum artifacts

Each artifact has a commitment that keeps it transparent:

| Artifact | Commitment | Description |
|----------|------------|-------------|
| **Product Backlog** | Product Goal | An ordered, evolving list of everything the product may need: features, improvements, bug fixes. Owned by the Product Owner. |
| **Sprint Backlog** | Sprint Goal | The Sprint Goal, the Product Backlog items selected for the Sprint, and the plan (tasks) to deliver them. Owned by the Developers. |
| **Increment** | Definition of Done | A usable, finished step towards the Product Goal. Work counts only if it meets the Definition of Done. |

## Product Backlog vs. Sprint Backlog

| | Product Backlog | Sprint Backlog |
|---|---|---|
| Scope | The whole product | One Sprint only |
| Owner | Product Owner | Developers |
| Lifetime | Lives as long as the product | Ends with the Sprint |
| Detail | Top items are detailed, lower items are rough | Items broken down into tasks |
| Changes | Continuously refined | Updated by the Developers during the Sprint |

**Backlog refinement** is the ongoing activity of clarifying, splitting and estimating Product Backlog items so the top of the backlog is ready for Sprint Planning.

## Definition of Done (DoD)

A shared checklist describing when work is complete. Example for a student project: code reviewed, tests pass, no known critical bugs, documentation updated, demo-able. It is the same for every item and prevents "done except for testing".

## Scrum values

Commitment, Focus, Openness, Respect and Courage.

## Estimation (brief)

Teams often estimate relative effort in **story points** (a size, not hours), using values like 1, 2, 3, 5, 8. **Velocity** is the number of points the team usually completes in a Sprint; it helps in planning but is not a target to push up.

## Typical Sprint flow

```
Product Backlog -> Sprint Planning -> Sprint (Daily Scrums) -> Increment
      ^                                                           |
      |                                                  Sprint Review (feedback)
      +--------- Retrospective (improve how we work) <------------+
```
