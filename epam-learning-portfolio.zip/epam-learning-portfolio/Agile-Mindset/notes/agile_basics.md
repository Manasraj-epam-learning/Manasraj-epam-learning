# Agile Methodology and Mindset

Status: in progress. These are introductory notes.

## What is Agile?

Agile is an approach to building software in **small increments**, getting **frequent feedback** and **adapting to change**, instead of planning everything up front and delivering once at the end (the traditional "waterfall" approach).

| | Waterfall | Agile |
|---|---|---|
| Planning | Detailed plan up front | Plan continuously in short cycles |
| Delivery | One big delivery at the end | Small working increments, often |
| Change | Expensive and discouraged | Expected and welcomed |
| Customer feedback | Mostly at the end | Throughout |
| Risk | Problems found late | Problems found early |

Agile is an umbrella term. Scrum, Kanban and Extreme Programming (XP) are specific frameworks and practices that follow Agile ideas.

## Agile Manifesto: the four values (2001)

The manifesto says that, while there is value in the items on the right, we value the items on the left more:

1. **Individuals and interactions** over processes and tools
2. **Working software** over comprehensive documentation
3. **Customer collaboration** over contract negotiation
4. **Responding to change** over following a plan

Meaning: processes, documents, contracts and plans still matter. They are just not more important than people, a working product, collaboration and the ability to adapt.

## The twelve principles, in my own words

1. Satisfy the customer by delivering valuable software early and continuously.
2. Welcome changing requirements, even late in development.
3. Deliver working software frequently, preferring shorter timescales.
4. Business people and developers work together daily.
5. Build projects around motivated people and trust them.
6. Face-to-face conversation is the most effective way to share information.
7. Working software is the main measure of progress.
8. Keep a sustainable pace that the team can maintain indefinitely.
9. Continuous attention to technical excellence and good design improves agility.
10. Simplicity, meaning maximising the work not done, is essential.
11. The best designs come from self-organising teams.
12. At regular intervals the team reflects on how to become more effective and adjusts.

## Agile mindset

A mindset is how a person thinks and behaves. Practising Agile ceremonies without the mindset is "going through the motions". The Agile mindset means:

- **Learning over blaming**: mistakes are information that helps the team improve.
- **Collaboration over silos**: the whole team owns the outcome.
- **Embracing change**: new information is an opportunity, not an attack on the plan.
- **Delivering value**: focus on what is useful to users, not on looking busy.
- **Transparency**: progress and problems are visible to everyone.
- **Continuous improvement**: always ask "how can we do this better next time?"

## Agile vs. Scrum

Agile is the philosophy; Scrum is one framework that applies it with defined roles, events and artifacts (see `scrum_fundamentals.md`).
