# Practical Scenarios

Five realistic situations and how an Agile team would handle them. These are learning exercises based on the Scrum framework, not records of a real project.

## Scenario 1: The client asks for a new feature in the middle of a Sprint

**Situation.** On day 4 of a 2-week Sprint the client asks the team to add a new "export to PDF" feature.

**Agile response.** The Developers do not silently add it. The request goes to the Product Owner, who adds it to the Product Backlog and decides its priority. If it is more valuable than a Sprint item, the Product Owner and Developers can discuss swapping scope without endangering the Sprint Goal. If it is not urgent, it is considered in the next Sprint Planning.

**Why.** Agile welcomes change, but through the Product Owner and at sensible points. This protects the Sprint Goal and keeps the team focused.

## Scenario 2: A developer is blocked and says so in the Daily Scrum

**Situation.** At the Daily Scrum, a developer says they cannot continue because they are waiting for access to a test server.

**Agile response.** The blocker is raised as an impediment. The Scrum Master takes ownership of getting it resolved (contacting the right person) and follows up. The Daily Scrum itself stays within 15 minutes; any detailed problem-solving happens in a short conversation afterwards between the people involved.

**Why.** The Daily Scrum exists to inspect progress and adapt the plan. Making impediments visible early prevents silent delays.

## Scenario 3: A stakeholder is unhappy with the feature in the Sprint Review

**Situation.** The team demonstrates a new search feature and a stakeholder says it does not match what they imagined.

**Agile response.** The team treats this as valuable feedback, not failure. They ask clarifying questions, and the Product Owner records the changes as new or updated Product Backlog items to be prioritised for upcoming Sprints.

**Why.** Early feedback on a small increment is far cheaper than discovering the mismatch after months of work. This is the reason for short cycles.

## Scenario 4: The same bugs keep appearing every Sprint

**Situation.** Over three Sprints, similar bugs reach the testing stage because code reviews are often skipped when the team is rushed.

**Agile response.** In the Sprint Retrospective, the team discusses the cause without blaming individuals and agrees on one concrete improvement, for example "every item needs one peer review before it is moved to Done", and adds it to the Definition of Done. The next retrospective checks whether the bug count dropped.

**Why.** Retrospectives drive continuous improvement. Good action items are specific, owned by someone and reviewed later.

## Scenario 5: The team consistently fails to finish what it plans

**Situation.** The team plans 40 story points each Sprint but completes about 25.

**Agile response.** The team looks at its real velocity over recent Sprints and plans close to that, rather than relying on optimism. It splits large stories into smaller ones, estimates together, and considers capacity (holidays, exams, other commitments). The discussion focuses on improving the planning process, not on pressuring people to work faster.

**Why.** Planning based on evidence leads to predictable delivery. A sustainable pace is an Agile principle; overcommitting leads to stress and lower quality.

## Common pattern across the scenarios

Make problems visible early, decide as a team, use feedback to adapt the plan, and improve the way of working step by step.
