# User Stories and Acceptance Criteria

## User story

A short description of a feature from the point of view of the person who needs it.

```
As a <type of user>,
I want <a goal or action>,
so that <the benefit or reason>.
```

Example: *As a student, I want to add a study task with a due date, so that I do not forget my deadlines.*

A story is a reminder to have a conversation, not a full specification. The details come from talking to the user and the Product Owner.

## INVEST: what makes a good story

| Letter | Meaning |
|--------|---------|
| **I**ndependent | Can be built and delivered on its own as far as possible |
| **N**egotiable | Details can be discussed; it is not a fixed contract |
| **V**aluable | Gives value to a user or customer |
| **E**stimable | The team understands it well enough to estimate |
| **S**mall | Fits within a single Sprint |
| **T**estable | There is a clear way to confirm it works |

## Acceptance criteria

Conditions that must be true for the story to be accepted. They make the story testable and avoid misunderstandings. A common format is **Given / When / Then**:

```
Given <a starting situation>
When  <the user does something>
Then  <the expected result>
```

### Worked example

**Story:** As a student, I want to add a study task with a due date, so that I do not forget my deadlines.

**Acceptance criteria:**

1. Given I am on the task page, when I enter a title and a future due date and press Save, then the task appears in my task list.
2. Given I leave the title empty, when I press Save, then I see the message "Title is required" and no task is created.
3. Given I enter a due date in the past, when I press Save, then I see a warning and the task is not saved.

## Acceptance criteria vs. Definition of Done

- **Acceptance criteria** are specific to *one* story ("a past date shows a warning").
- **Definition of Done** applies to *all* stories ("code reviewed, tests pass").

A story is finished only when both are satisfied.

## Common mistakes

- Writing technical tasks as stories ("Create database table"). Tasks belong in the Sprint Backlog under a story.
- Stories too large to finish in a Sprint (split them, for example "add task" first, "edit task" later).
- Missing the "so that", which hides the real value.
- Vague criteria such as "works well" or "is fast".
