# Agile Mindset

**Status: IN PROGRESS**

## Overview

This folder covers Agile methodology and the Scrum framework, and applies them to a small sample project. It is a theory and practice topic, so it contains notes and a worked exercise instead of code.

## Concepts covered so far

- Agile vs. waterfall; the Agile Manifesto values and principles
- The Agile mindset
- Scrum roles, events and artifacts
- Sprint Planning, Daily Scrum, Sprint Review, Sprint Retrospective
- Product Backlog vs. Sprint Backlog, Definition of Done
- User stories, INVEST and acceptance criteria (Given / When / Then)
- Five practical scenarios with explanations

## Folder structure

```
Agile-Mindset/
├── README.md
├── notes/
│   ├── agile_basics.md          # methodology, values, principles, mindset
│   ├── scrum_fundamentals.md    # roles, events, artifacts, backlogs, DoD
│   ├── user_stories.md          # user stories and acceptance criteria
│   └── practical_scenarios.md   # 5 real-world scenarios
└── exercises/
    ├── product_backlog.md       # sample product backlog (8 user stories)
    └── sprint_backlog.md        # sample Sprint 1 plan with tasks and criteria
```

## Suggested reading order

1. `notes/agile_basics.md`
2. `notes/scrum_fundamentals.md`
3. `notes/user_stories.md`
4. `notes/practical_scenarios.md`
5. `exercises/product_backlog.md`, then `exercises/sprint_backlog.md`

## The practical exercise

The exercises use an imagined project, "Smart Study Planner". I wrote a prioritised Product Backlog, selected three stories for a first Sprint, defined a Sprint Goal, wrote acceptance criteria, broke the stories into tasks and listed a Definition of Done. The project and the team are fictional and were created only for practice.

## Key learning outcomes so far

- I can explain the Agile values and how Scrum applies them.
- I can describe the purpose and timebox of each Scrum event.
- I can write a user story with testable acceptance criteria.
- I can explain how a Product Backlog item becomes Sprint Backlog tasks.
- I can reason through typical team situations such as changing requirements, blockers and repeated bugs.
