# Exercise: Product Backlog for a Sample Project

This is a practice exercise created to apply Scrum concepts. It is not a real client project.

**Project:** Smart Study Planner, a simple web application for students to plan study tasks.

**Product Goal:** Help students organise their study tasks and deadlines in one place.

**Stakeholders (imagined):** students (users), mentor (reviewer). The team plays the Product Owner role when ordering the backlog.

## Product Backlog (ordered by priority)

Story points use the scale 1, 2, 3, 5, 8 and are rough estimates.

| ID | User story | Priority | Points |
|----|-----------|----------|--------|
| PB-1 | As a student, I want to add a study task with a title and due date, so that I do not forget deadlines. | High | 3 |
| PB-2 | As a student, I want to see all my tasks in a list sorted by due date, so that I know what to do first. | High | 3 |
| PB-3 | As a student, I want to mark a task as completed, so that I can track my progress. | High | 2 |
| PB-4 | As a student, I want to edit or delete a task, so that I can correct mistakes or remove tasks I no longer need. | Medium | 3 |
| PB-5 | As a student, I want to filter tasks by subject, so that I can focus on one subject at a time. | Medium | 3 |
| PB-6 | As a student, I want a reminder for tasks due tomorrow, so that I do not miss them. | Medium | 5 |
| PB-7 | As a student, I want to see a weekly progress summary, so that I can understand how much I completed. | Low | 5 |
| PB-8 | As a student, I want to log in with my own account, so that my tasks stay private. | Low | 8 |

## Notes on ordering

- PB-1 to PB-3 are first because together they form the smallest useful product (add, view, complete).
- PB-8 (login) is large and not needed to get early feedback, so it is placed lower. The order can change after feedback in a Sprint Review.
- Items near the top are small and well understood; items near the bottom are still rough and will be refined later (backlog refinement).
