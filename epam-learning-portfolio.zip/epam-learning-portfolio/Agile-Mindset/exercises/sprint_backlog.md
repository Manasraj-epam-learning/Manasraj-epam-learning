# Exercise: Sample Sprint Backlog (Sprint 1)

This is a practice exercise based on the Product Backlog in `product_backlog.md`. It shows how a team might plan a Sprint. It is an illustration, not a record of a real Sprint.

## Sprint details

| Item | Value |
|------|-------|
| Sprint length | 2 weeks |
| Team (example) | 4 Developers, 1 Product Owner, 1 Scrum Master |
| Capacity assumption | The team expects to complete about 8 story points (new team, so a cautious estimate) |
| Selected items | PB-1 (3 pts), PB-2 (3 pts), PB-3 (2 pts) = 8 points |

## Sprint Goal

> A student can add a task, see their tasks sorted by due date, and mark tasks as completed.

## Selected stories with acceptance criteria

### PB-1: Add a study task (3 points)

- Given I am on the task page, when I enter a title and a due date and press Save, then the task appears in my list.
- Given the title is empty, when I press Save, then I see "Title is required" and nothing is saved.
- Given the due date is in the past, when I press Save, then I see a warning and nothing is saved.

### PB-2: View tasks sorted by due date (3 points)

- Given I have several tasks, when I open the task list, then the task with the earliest due date appears first.
- Given I have no tasks, when I open the list, then I see the message "No tasks yet".

### PB-3: Mark a task as completed (2 points)

- Given a task is in my list, when I mark it completed, then it is shown as completed and is visually distinct.
- Given I mark a task completed by mistake, when I unmark it, then it returns to pending.

## Sprint Backlog: tasks

| Story | Task | Owner | Status |
|-------|------|-------|--------|
| PB-1 | Design the add-task form | Developer A | To do |
| PB-1 | Implement the form and input validation | Developer B | To do |
| PB-1 | Store tasks (in-memory list first) | Developer B | To do |
| PB-1 | Write tests for validation rules | Developer C | To do |
| PB-2 | Implement sorting by due date | Developer C | To do |
| PB-2 | Build the task list page with empty state | Developer A | To do |
| PB-3 | Add completed/pending toggle | Developer D | To do |
| PB-3 | Style completed tasks | Developer A | To do |
| All | Peer review of every change | Whole team | To do |
| All | Update README with how to run the app | Developer D | To do |

(Statuses are "To do" because this is the planning view at the start of the Sprint. During a real Sprint they would move through "In progress" and "Done".)

## Definition of Done (example)

- Code has been reviewed by at least one other team member.
- All acceptance criteria of the story are met.
- Tests for the story pass.
- No known critical bugs.
- README or notes updated if behaviour changed.
- The feature can be demonstrated in the Sprint Review.

## How the Sprint events would look

| Event | What happens in this example |
|-------|------------------------------|
| Sprint Planning | Team agrees the Sprint Goal, picks PB-1 to PB-3, breaks them into the tasks above. |
| Daily Scrum (15 min) | Each Developer shares progress towards the Sprint Goal, plans for the next 24 hours, and raises blockers. |
| Sprint Review | Team demonstrates add, list and complete; stakeholders give feedback that may change the Product Backlog order. |
| Sprint Retrospective | Team discusses what went well, what did not, and agrees one or two improvements for Sprint 2. |

## Reflection template (to fill in after a real Sprint)

- What went well?
- What did not go well?
- What will we change in the next Sprint (one specific action, with an owner)?
